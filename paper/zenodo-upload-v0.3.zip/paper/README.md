# Project Drexel paper, version 0.3

This directory contains Jashid Sany's quality-assured Project Drexel working preprint for Advent Cybersecurity, prepared 27 November 2026. Version 0.3 supersedes version 0.2, which remains in the repository and Git history. The revision develops a doctoral-style preliminary research framework around local model capability, polymorphism, environment coverage, serial code revision, and defender observability. It does not report a completed dissertation, a Drexel experiment, or a measured universal adaptation or detection-evasion rate.

## Files for a Zenodo deposit

- `drexel-feasibility-v0.3.pdf`: reader-facing preprint.
- `zenodo-upload-v0.3.zip`: LaTeX source, PDF, all current research notes, data records, and benign evaluation scripts in the `docs`, `data`, and `scripts` directories, plus this guide and a file-hash manifest. The archive preserves the evidence snapshot independently of later changes to the [public research repository](https://github.com/Advent-Cybersecurity/advent-drexel). Its external source URLs and online session-handoff link still require network access.
- `drexel-feasibility-v0.3.tex`: editable single-file LaTeX source.

Upload the PDF and ZIP together as one versioned Zenodo record. The ZIP already contains the PDF, so the separate PDF is for direct viewing. Set the publication date to the deposit date, version to `0.3`, and resource type to a publication/preprint or working paper as Zenodo offers. Suggested keywords: `Project Drexel`, `polymorphic malware`, `local language models`, `environmental adaptation`, `defender observability`. Enter **Jashid Sany** as creator with **Advent Cybersecurity** as affiliation. Zenodo's required license field remains a deposit-time publication choice; no DOI or license has been presumed in the manuscript.

The public abstract can be copied from the PDF. The paper's evidence cutoff is 27 November 2026. Later research and testing should receive a new version rather than an unmarked overwrite.

## Rebuild

From this directory, run:

```powershell
tectonic drexel-feasibility-v0.3.tex
```

The TeX file uses a self-contained `thebibliography` block and standard packages. No BibTeX step is needed. The PDF displays complete, clickable source URLs that remain traceable in print.

The packaged evidence files include descriptive research records and benign evaluation scripts, not malware samples or operational payloads. The 512-entry source registry is a heterogeneous bibliography. The 31-case ledger is relevance selected for the serial-revision subclaim and does not provide a trial denominator for the wider Project Drexel questions. The archived ledger has four link statuses and explanatory notes, not uniform structured per-case extraction of every attribute considered in the narrative review.

Run `python make_zenodo_bundle.py` after the last PDF or text change. It writes the ZIP and `SHA256SUMS-v0.3.txt` for the archived files. Zenodo's [deposit guidance](https://help.zenodo.org/docs/deposit/create-new-upload/) describes the required metadata and preview; its [versioning guidance](https://help.zenodo.org/docs/deposit/manage-versions/) treats later changed files as a new record version. Zenodo [requires a license field](https://help.zenodo.org/docs/deposit/describe-records/licenses/), which the Advent Cybersecurity depositor can set when publishing.
