# Project Drexel paper, version 0.2

This directory contains Jashid Sany's revised Project Drexel working preprint for Advent Cybersecurity, prepared 27 November 2026. Version 0.2 supersedes the earlier draft, which remains recoverable from Git history. The revision develops a doctoral-style research framework around local model capability, polymorphism, environment coverage, serial code revision, and defender observability. It does not report a completed Drexel experiment or a measured universal adaptation or detection-evasion rate.

## Files for a Zenodo deposit

- `drexel-feasibility-v0.2.pdf`: reader-facing revised preprint.
- `zenodo-upload-v0.2.zip`: LaTeX source, PDF, dated search protocol, source registry, selected-case ledger, and cross-case synthesis. The archive fixes this version's evidence trail independently of later changes to the [public research repository](https://github.com/Advent-Cybersecurity/advent-drexel).
- `drexel-feasibility-v0.2.tex`: editable single-file LaTeX source.

Upload the PDF and ZIP together as one versioned Zenodo record. The ZIP already contains the PDF, so the separate PDF is for direct viewing. Set the publication date to the deposit date, version to `0.2`, and resource type to a publication/preprint or working paper as Zenodo offers. Suggested keywords: `Project Drexel`, `polymorphic malware`, `local language models`, `environmental adaptation`, `defender observability`. Enter **Jashid Sany** as creator with **Advent Cybersecurity** as affiliation. Zenodo's required license field remains a deposit-time publication choice; no DOI or license has been presumed in the manuscript.

The public abstract can be copied from the PDF. The paper's evidence cutoff is 27 November 2026. Later research and testing should receive a new version rather than an unmarked overwrite.

## Rebuild

From this directory, run:

```powershell
tectonic drexel-feasibility-v0.2.tex
```

The TeX file uses a self-contained `thebibliography` block and standard packages. No BibTeX step is needed. The URLs are present in the TeX source and source registry; the PDF displays clickable source domains for compact references.

The packaged evidence files are descriptive research records, not source code or payloads. The 512-entry source registry is a heterogeneous bibliography. The 31-case ledger is relevance selected for the serial-revision subclaim and does not provide a trial denominator for the wider Project Drexel questions.

Run `python make_zenodo_bundle.py` after the last PDF or text change. It writes the ZIP and `SHA256SUMS-v0.2.txt` for the archived files. Zenodo's [deposit guidance](https://help.zenodo.org/docs/deposit/create-new-upload/) describes the required metadata and preview; its [versioning guidance](https://help.zenodo.org/docs/deposit/manage-versions/) treats later changed files as a new record version. Zenodo [requires a license field](https://help.zenodo.org/docs/deposit/describe-records/licenses/), which the Advent Cybersecurity depositor can set when publishing.
