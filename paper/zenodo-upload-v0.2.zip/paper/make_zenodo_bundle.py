"""Create the current Project Drexel evidence snapshot for one Zenodo deposit."""

from __future__ import annotations

import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper"
VERSION = "v0.2"
FILES = (
    "paper/drexel-feasibility-v0.2.pdf",
    "paper/drexel-feasibility-v0.2.tex",
    "paper/README.md",
    "paper/make_zenodo_bundle.py",
    "data/sources.json",
    "data/closest-case-claim-ledger-2026-11-26.json",
    "docs/source-search-and-evidence-protocol-2026-11-26.md",
    "docs/claim-ledger-cross-case-synthesis-2026-11-26.md",
    "docs/source-review-decision-brief-2026-11-26.md",
    "docs/research-log-2026-11-26.md",
    "docs/paper-revision-source-log-2026-11-27.md",
)


def add_bytes(archive: ZipFile, name: str, content: bytes) -> None:
    info = ZipInfo(name, date_time=(2026, 11, 27, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    archive.writestr(info, content)


def main() -> None:
    payloads = {}
    for name in FILES:
        path = ROOT / name
        if not path.is_file():
            raise FileNotFoundError(path)
        payloads[name] = path.read_bytes()

    checksums = "".join(
        f"{hashlib.sha256(content).hexdigest()}  {name}\n"
        for name, content in payloads.items()
    ).encode("ascii")
    manifest_name = f"SHA256SUMS-{VERSION}.txt"
    (PAPER / manifest_name).write_bytes(checksums)

    bundle = PAPER / f"zenodo-upload-{VERSION}.zip"
    with ZipFile(bundle, "w") as archive:
        for name, content in payloads.items():
            add_bytes(archive, name, content)
        add_bytes(archive, manifest_name, checksums)
    print(f"Created {bundle} ({bundle.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
